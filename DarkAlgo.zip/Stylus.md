## 사용법 (Stylus)
1. [Stylus](https://chrome.google.com/webstore/detail/stylus/clngdbkpkpeebahjckkjfobafhncgmne?hl=ko&)라는 확장 프로그램을 설치한다.
2. [DarkAlgo](https://raw.githubusercontent.com/1-EXON/DarkAlgo/master/css/style.user.css) 에 들어가 Install 한다.