# DarkAlgo
백준 다크다크 확장 프로그램

## 사용법
1. [DarkAlgo](https://chrome.google.com/webstore/detail/darkalgo/denihfakafbbponodcpmchiglahicadg?hl=ko&) 확장 프로그램을 설치한다. (크롬 확장프로그램 제출중..)
- 너무 css 적용 속도가 느리시다면 [Sytlus](https://github.com/1-EXON/DarkAlgo/blob/master/Stylus.md)를 이용해보세요!

## Preview (v1.2.4)
<img src="preview/1.png"> <br> 
<img src="preview/2.png">
<br>
<img src="preview/3.png">

## 이슈와 PR은 환영입니다!
+ 이슈를 보내주실 때 변경하고 싶은 부분을 캡처해서 보내주세요